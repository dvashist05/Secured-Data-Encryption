# ATM-Prototype
## Sem 4 (Even Semester'20) UnderGrad Project- Bennett University, Greater Noida
Data Encryption and cryptography
Used python to implement an ATM prototype.
(Please read project SRS)
